#!/bin/bash

echo "Listado de directorios en el directorio actual:"
ls -d */
