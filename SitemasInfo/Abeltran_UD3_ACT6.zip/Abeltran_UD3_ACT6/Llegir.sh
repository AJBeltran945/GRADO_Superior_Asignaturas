#!/bin/bash

echo -n "Introdueix el nom d'un arxiu de text: "
read nom_arxiu

if [ -f "$nom_arxiu" ]; then
    nombre_linies=0

    for line in $(cat "$nom_arxiu"); do
        ((nombre_linies++))
    done

    echo "L'arxiu $nom_arxiu té $nombre_linies línies."
else
    echo "Error: L'arxiu $nom_arxiu no existeix o no és un arxiu de text."
fi
