#el comandament dpkg s'empra per instal·lar, desinstal·lar, actualitzar i gestionar paquets de software en sistemes operatius com l'Ubuntu

aplicacio="aplicacio"

if [ -x "$(command -v $aplicacio)" ]; then
	echo "L'aplicació "$aplicacio" està instal·lada."
else
	echo "L'aplicació "$aplicacio" no està instal·lada."
fi