directori="directori"

if [ -d "$directori" ]; then
	echo "El directori "$directori" ja existeix."
else
	mkdir "$directori"
	echo "S'ha creat el directori "$directori"."
fi

cd "$directori" 

touch "$arxiu"
echo "S'ha creat un arxiu anomenat "$arxiu" dins en directori "$directori"."