frutas="frutas.txt"

if [ ! -f "$frutas" ]; then
	echo "l'arxiu "$frutas" no existeix."
	exit 1
fi

frutas_ordenadas="frutas_ordenadas.txt"

sort "$frutas" > "$frutas_ordenadas"

cat "$frutas_ordenadas"