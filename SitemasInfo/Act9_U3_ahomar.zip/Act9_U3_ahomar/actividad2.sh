if [ "$EUID" -eq 0 ]; then
	echo "És root"
else
	echo "Necessites privilegis d'administrador"
fi

sudo apt update

sudo apt install -y gimp htop

if [ $? -eq 0 ]; then
	echo "S'han instal·lat correctament."
else
	echo "Error en al instal·lar."
fi
	